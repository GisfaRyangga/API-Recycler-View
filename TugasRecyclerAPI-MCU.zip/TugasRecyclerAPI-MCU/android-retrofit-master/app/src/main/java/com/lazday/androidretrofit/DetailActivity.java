package com.lazday.androidretrofit;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

public class DetailActivity extends AppCompatActivity {
    TextView txtnama;
    String name, image;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        txtnama = findViewById(R.id.txtNama);

        name = getIntent().getStringExtra("intent_title");
        image = getIntent().getStringExtra("intent_image");
        getSupportActionBar().setTitle(name);
        Picasso.get()
                .load( image )
                .placeholder(R.drawable.ic_launcher_background)
                .error(R.drawable.ic_launcher_background)
                .into((ImageView)findViewById(R.id.imageView) );
        txtnama.setText(name);
    }
}